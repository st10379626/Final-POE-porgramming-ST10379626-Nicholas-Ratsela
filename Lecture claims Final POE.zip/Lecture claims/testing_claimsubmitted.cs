﻿
namespace Lecture_claims
{
    public class testing_claimsubmitted
    {
        //claim method

       // public string claim(string lecturename, string Numberofhours, string Groups, string HourlyRate, string Module, string SupoortingDocuments);

                
    }
}
