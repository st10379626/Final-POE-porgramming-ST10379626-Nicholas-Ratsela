using Lecture_claims.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Reflection.Metadata;

namespace Lecture_claims.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly lectureclaimsDbcontext _context;



        public HomeController(ILogger<HomeController> logger, lectureclaimsDbcontext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Expensess(Expenses model)
        {
            var allExpensess = _context.Expensess.ToList();  

            //var totalExpensess = allExpensess.Sum(x => x.HourlyRate);
           

            //ViewBag.Expensess = totalExpensess;

            return View(allExpensess);
        }

        public IActionResult Form(int? id)
        {
            if(id != null)
            {
                var expensessInDb = _context.Expensess.SingleOrDefault(Expensess => Expensess.LectureID == id);
                return View(expensessInDb);
            }
           
            return View();
        }

        public IActionResult DeleteExpenses(int id)
        {
            var expensessInDb = _context.Expensess.SingleOrDefault(Expensess => Expensess.LectureID == id);
            _context.Expensess.Remove(expensessInDb);
            _context.SaveChanges();
            return RedirectToAction("Expensess"); 
        }

        public IActionResult ClaimsApproval()
        {
            var allExpensess = _context.Expensess.ToList();
        
            return View(allExpensess);
        }

        public IActionResult HRView()
        {
            var allExpensess = _context.Expensess.ToList();

            return View(allExpensess);
        }

        public IActionResult Claimsaccepted()
        {
            var allExpensess = _context.Expensess.ToList();
            return View(allExpensess);
        
        }
        
        public IActionResult CreateForm(Expenses model)
        {

            if (model.LectureID == 0)
            {
                _context.Expensess.Add(model);
            }
            else
            {
                _context.Expensess.Update(model);
            }
            //calculate total
            model.Total = model.HourlyRate * model.Numberofhours;
            
            _context.SaveChanges();

             return RedirectToAction("Expensess");
        }

       

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
